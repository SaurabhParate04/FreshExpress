package com.socool.freshexpress.adaptor

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.socool.freshexpress.R
import com.socool.freshexpress.model.RestaurantMenu

class RestaurantMenuAdaptor(
    val context: Context,
    private val ItemList: ArrayList<RestaurantMenu>,
    private val listener: MenuItemClickListener
) : RecyclerView.Adapter<RestaurantMenuAdaptor.RestaurantMenuViewHolder>() {
    class RestaurantMenuViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val txtItemName: TextView = view.findViewById(R.id.txtSingleRowRestaurantMenuName)
        val txtPrice: TextView = view.findViewById(R.id.txtSingleRowRestaurantMenuPrice)
        val txtItemNo: TextView = view.findViewById(R.id.txtSingleRowRestaurantMenuItemNo)
        val btnAddToCart: Button = view.findViewById(R.id.btnAddRestaurantMenu)
        val btnRemoveFromCart: Button = view.findViewById(R.id.btnRemoveRestaurantMenu)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RestaurantMenuViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.single_row_recycler_restaurant_menu, parent, false)
        return RestaurantMenuViewHolder(view)
    }

    override fun getItemCount(): Int {
        return ItemList.size
    }

    interface MenuItemClickListener {
        fun addItemToCart(menuItem: RestaurantMenu)
        fun removeItemFromCart(menuItem: RestaurantMenu)
    }


    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: RestaurantMenuViewHolder, position: Int) {
        val foodItem = ItemList[position]
        holder.txtItemName.text = foodItem.name
        holder.txtPrice.text = "Rs. " + foodItem.price.toString()
        holder.txtItemNo.text = (position + 1).toString()
        holder.btnAddToCart.setOnClickListener {
            holder.btnAddToCart.visibility = View.GONE
            holder.btnRemoveFromCart.visibility = View.VISIBLE
            listener.addItemToCart(foodItem)
        }
        holder.btnRemoveFromCart.setOnClickListener {
            holder.btnRemoveFromCart.visibility = View.GONE
            holder.btnAddToCart.visibility = View.VISIBLE
            listener.removeItemFromCart(foodItem)
        }
    }
}